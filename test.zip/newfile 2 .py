from turtle import *
speed(1)
width(4)
bgcolor('black')
color('blue')

begin_fill()

penup()

goto(-50,60)
pendown()
goto(100,100)
goto(100,-100)
goto(-50,-60)
goto(-50,60)

end_fill()

penup()

color('black')
width(10)


goto(-50,0)
pendown()
goto(100,0)

penup()

goto(25,80)
pendown()
goto(25,-80)

done()